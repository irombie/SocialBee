package neo4j;

public class GraphNode {

	
}
