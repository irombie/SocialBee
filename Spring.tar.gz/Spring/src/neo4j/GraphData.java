package neo4j;

import java.util.ArrayList;

public class GraphData {

	private ArrayList<GraphNode> nodes ;

	public ArrayList<GraphNode> getNodes() {
		return nodes;
	}

	public void setNodes(ArrayList<GraphNode> nodes) {
		this.nodes = nodes;
	}

	
	
}
