package neo4j;

public class Director extends GraphNode{
	private DirectorData data;

	public DirectorData getData() {
		return data;
	}

	public void setData(DirectorData data) {
		this.data = data;
	}
	
	
}
