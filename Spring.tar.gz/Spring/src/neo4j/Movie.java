package neo4j;

public class Movie extends GraphNode{
	
	private MovieData data;

	public MovieData getData() {
		return data;
	}

	public void setData(MovieData data) {
		this.data = data;
	}

	

	
	
}
