package neo4j;

public enum NodeKey {
	a,m,d

}
