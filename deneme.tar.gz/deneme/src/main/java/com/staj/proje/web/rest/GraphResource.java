package com.staj.proje.web.rest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.codahale.metrics.annotation.Timed;

import com.staj.proje.domain.User;
import com.staj.proje.repository.UserRepository;
import com.staj.proje.security.SecurityUtils;
import com.staj.proje.service.MailService;
import com.staj.proje.service.UserService;
import com.staj.proje.web.rest.dto.KeyAndPasswordDTO;
import com.staj.proje.web.rest.dto.ManagedUserDTO;
import com.staj.proje.web.rest.dto.UserDTO;
import com.staj.proje.web.rest.util.HeaderUtil;

import org.apache.commons.lang.StringUtils;

import javax.inject.Inject;
import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.net.URL;
import java.util.*;
import java.net.URLEncoder;

import com.staj.proje.Node;
/**
 * REST controller for managing Item.
 */
@RestController
@RequestMapping("/api")
public class GraphResource {

    @RequestMapping(value="/nodes",
            method = RequestMethod.GET,
            produces={MediaType.APPLICATION_JSON_VALUE, MediaType.TEXT_PLAIN_VALUE} )
    public ResponseEntity<String> post_json() throws URISyntaxException {
    	BufferedReader reader = null;
        String input = "";
        String inputLine = "";
        try {
            URL url = new URL("http://10.150.25.16:8080/GraphData");
            reader = new BufferedReader(new InputStreamReader(url.openStream()));
            
            while((inputLine = reader.readLine()) != null) {
                System.out.println(inputLine);
                input = inputLine;
            }

            reader.close();
        }
        catch(IOException e) {
            System.out.println(e);
        }

        return new ResponseEntity<String>(input, HttpStatus.OK);
    }

    @RequestMapping(value="/movies",
            method = RequestMethod.GET,
            produces={MediaType.APPLICATION_JSON_VALUE, MediaType.TEXT_PLAIN_VALUE} )
    public ResponseEntity<String> get_movies() throws URISyntaxException {
        BufferedReader reader = null;
        String input = "";
        String inputLine = "";
        try {
            URL url = new URL("http://10.150.25.16:8080/Movies");
            reader = new BufferedReader(new InputStreamReader(url.openStream()));
            
            while((inputLine = reader.readLine()) != null) {
                System.out.println(inputLine);
                input = inputLine;
            }

            reader.close();
        }
        catch(IOException e) {
            System.out.println(e);
        }

        return new ResponseEntity<String>(input, HttpStatus.OK);        
    }

    @RequestMapping(value="/people",
            method = RequestMethod.GET,
            produces={MediaType.APPLICATION_JSON_VALUE, MediaType.TEXT_PLAIN_VALUE} )
    public ResponseEntity<String> get_people() throws URISyntaxException {
        BufferedReader reader = null;
        String input = "";
        String inputLine = "";
        try {
            URL url = new URL("http://10.150.25.16:8080/People");
            reader = new BufferedReader(new InputStreamReader(url.openStream()));
            
            while((inputLine = reader.readLine()) != null) {
                System.out.println(inputLine);
                input = inputLine;
            }

            reader.close();
        }
        catch(IOException e) {
            System.out.println(e);
        }

        return new ResponseEntity<String>(input, HttpStatus.OK);    
    }

    @RequestMapping(value="/shortestPath",
            method = RequestMethod.POST,
            produces={MediaType.APPLICATION_JSON_VALUE, MediaType.TEXT_PLAIN_VALUE} )
    public ResponseEntity<String> shortest_path_json(@RequestBody String names) throws URISyntaxException {
        BufferedReader reader = null;
        String input = "";
        String inputLine = "";
        System.out.println("\n\n\nSEND SHORTEST PATH\n\n\n\n");
        try {
            System.out.println(names);
            String[] values = names.split("&");
            System.out.println(values[0]);
            System.out.println(values[1]);
            System.out.println(URLEncoder.encode(values[0], "UTF-8"));
            System.out.println(URLEncoder.encode(values[1], "UTF-8"));

            String value1 = values[0].replaceAll("%20", " ");
            String value2 = values[1].replaceAll("%20", " ");


            System.out.println(URLEncoder.encode(names, "UTF-8"));

            URL url = new URL("http://10.150.25.16:8080/ShortestPathM2P?" + names);
            //URL url = new URL("http://10.150.25.16:8080/ShortestPathM2M");
            reader = new BufferedReader(new InputStreamReader(url.openStream()));
            
            while((inputLine = reader.readLine()) != null) {
                System.out.println(inputLine);
                input = inputLine;
            }

            reader.close();
        }
        catch(IOException e) {
            System.out.println(e);
        }

        return new ResponseEntity<String>(input, HttpStatus.OK);
    }


    @RequestMapping(value="/sendMovie",
            method = RequestMethod.POST,
            produces={MediaType.APPLICATION_JSON_VALUE, MediaType.TEXT_PLAIN_VALUE} )
    public ResponseEntity<String> send_movie_json(@RequestBody String movie_name) throws URISyntaxException {

        System.out.println("\n\n\nSEND MOVIE\n\n\n\n");
        BufferedReader reader = null;
        String input = "";
        String inputLine = "";
        System.out.println(movie_name);
        try {
            URL url = new URL("http://10.150.25.16:8080/GraphData?movieName=" + URLEncoder.encode(movie_name, "UTF-8"));
            reader = new BufferedReader(new InputStreamReader(url.openStream()));
            
            while((inputLine = reader.readLine()) != null) {
                System.out.println(inputLine);
                input = inputLine;
            }

            reader.close();
        }
        catch(IOException e) {
            System.out.println(e);
        }
        System.out.println(input);
        return new ResponseEntity<String>(input, HttpStatus.OK);
    }

}