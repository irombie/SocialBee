package com.staj.proje.web.rest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.codahale.metrics.annotation.Timed;

import com.staj.proje.domain.User;
import com.staj.proje.repository.UserRepository;
import com.staj.proje.security.SecurityUtils;
import com.staj.proje.service.MailService;
import com.staj.proje.service.UserService;
import com.staj.proje.web.rest.dto.KeyAndPasswordDTO;
import com.staj.proje.web.rest.dto.ManagedUserDTO;
import com.staj.proje.web.rest.dto.UserDTO;
import com.staj.proje.web.rest.util.HeaderUtil;

import org.apache.commons.lang.StringUtils;

import javax.inject.Inject;
import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.net.URL;
import java.util.*;

import com.staj.proje.Node;
/**
 * REST controller for managing Item.
 */
@RestController
@RequestMapping("/api")
public class GraphResource {

    /**
     * POST  /items -> Create a new item.
     */

    /*@RequestMapping(value = "/get",
            method = RequestMethod.POST,
            produces=MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody ResponseEntity<Node> get() {

        Node node = new Node();
        node.setName("Irem");
        node.setSurname("Ergun");
        node.setAge(21);

        return new ResponseEntity<Node>(node, HttpStatus.OK);
    }*/

    @RequestMapping(value="/nodes",
            method = RequestMethod.GET,
            produces={MediaType.APPLICATION_JSON_VALUE, MediaType.TEXT_PLAIN_VALUE} )
    public ResponseEntity<ArrayList<Node>> post_json() throws URISyntaxException {
    //public String post_json() throws URISyntaxException {
    	System.out.println("irem");
    	//System.out.println(node.getAge());

        Node node1 = new Node("Fantastic Beasts and Where To Find Them", "David Yates", 2016, 0);
        Node node2 = new Node("Harry Potter", "David Yates", 2010, 1);
        Node node3 = new Node("Pirates of the Caribbean At World's End", "Gore Verbinski", 2007, 2);
        Node node4 = new Node("Inception", "Christopher Nolan", 2010, 3);
        Node node5 = new Node("V For Vendetta", "James McTeigue", 2006, 4);
        Node node6 = new Node("Avatar", "James Cameron", 2009, 5);

        ArrayList<Node> nodes = new ArrayList<Node>();
        nodes.add(node1);
        nodes.add(node2);
        nodes.add(node3);
        nodes.add(node4);
        nodes.add(node5);
        nodes.add(node6);

        /*BufferedReader reader = null;
        String input = "";
        try {
            URL url = new URL("10.150.25.16:8080/getGraphData");
            reader = new BufferedReader(new InputStreamReader(url.openStream()));
            StringBuffer buffer = new StringBuffer();
            int read;
            char[] chars = new char[1024];
            while ((read = reader.read(chars)) != -1)
                buffer.append(chars, 0, read); 

            input = buffer.toString();
            reader.close();
        }
        catch(IOException e) {
            System.out.println(e);
        }
        finally {
            //if (reader != null)
            //    reader.close();
        }

        System.out.println(input); */

        //String json = "{'index': 0, 'year': 2004,'director': 'Adela Melendez'}"; //{"_id": "57612e4bf93f82cc5217f06d", "index": 1, "title": "Friends", "year": 2003,  "genre": "horror","director": "White Knapp"}, {"_id": "57612e4b044bfba501ec3658","index": 2,"title": "Friends","year": 2015, "genre": "horror","director": "Dale Bernard"}, { "_id": "57612e4b6235d60d7de791db","index": 3,"title": "Friends","year": 2005,"genre": "sci-fi", "director": "Hull Edwards"}, {"_id": "57612e4b38a39e7a9aca7aeb","index": 4,"title": "Pirates of The Caribbean", "year": 2013,"genre": "sci-fi","director": "Opal Grant"}, {"_id": "57612e4be4577bf81e2a8c86", "index": 5, "title": "Pirates of The Caribbean", "year": 1999, "genre": "sci-fi","director": "Heath Le"}]';
        return new ResponseEntity<ArrayList<Node>>(nodes, HttpStatus.OK);
        //return json;
        
    }

    /*
     * PUT  /items -> Updates an existing item.
     
    @RequestMapping(value = "/items",
        method = RequestMethod.PUT,
        produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<Item> updateItem(@Valid @RequestBody Item item) throws URISyntaxException {
        log.debug("REST request to update Item : {}", item);
        if (item.getId() == null) {
            return createItem(item);
        }
        Item result = itemRepository.save(item);
        return ResponseEntity.ok()
                .headers(HeaderUtil.createEntityUpdateAlert("item", item.getId().toString()))
                .body(result);
    }

    /*
     * GET  /items -> get all the items.
     
    @RequestMapping(value = "/items",
            method = RequestMethod.GET,
            produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<List<Item>> getAllItems(Pageable pageable)
        throws URISyntaxException {
        Page<Item> page = itemRepository.findAll(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/items");
        return new ResponseEntity<>(page.getContent(), headers, HttpStatus.OK);
    }

    /*
     * DELETE  /items/:id -> delete the "id" item.
     
    @RequestMapping(value = "/items/{id}",
            method = RequestMethod.DELETE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    @Timed
    public ResponseEntity<Void> deleteItem(@PathVariable Long id) {
        log.debug("REST request to delete Item : {}", id);
        itemRepository.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert("item", id.toString())).build();
    } */
}